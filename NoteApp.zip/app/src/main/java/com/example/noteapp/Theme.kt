package com.example.noteapp

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 元のHTMLエディタと同じパレット
object NoteColors {
    val Bg        = Color(0xFF1A1A2E)
    val Surface   = Color(0xFF16213E)
    val Surface2  = Color(0xFF0F3460)
    val SurfaceEdit = Color(0xFF13172B)
    val Accent    = Color(0xFFE94560)
    val Accent2   = Color(0xFF533483)
    val OnBg      = Color(0xFFEAEAEA)
    val OnBg2     = Color(0xFFA0A0B8)
    val Border    = Color(0xFF2A2A4A)

    // Preview side (light)
    val PreviewBg = Color(0xFFFAFAFA)
    val PreviewFg = Color(0xFF222222)
}

private val DarkScheme = darkColorScheme(
    primary    = NoteColors.Accent,
    onPrimary  = Color.White,
    secondary  = NoteColors.Accent2,
    background = NoteColors.Bg,
    onBackground = NoteColors.OnBg,
    surface    = NoteColors.Surface,
    onSurface  = NoteColors.OnBg,
    surfaceVariant = NoteColors.Surface2,
    onSurfaceVariant = NoteColors.OnBg2,
    outline    = NoteColors.Border,
)

@Composable
fun NoteAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkScheme,
        content = content,
    )
}
