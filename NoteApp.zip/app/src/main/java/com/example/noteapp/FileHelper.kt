package com.example.noteapp

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

object FileHelper {

    /** 拡張子とMIMEのマッピング。SAFのCreateDocumentで指定する */
    val fileTypes: List<FileType> = listOf(
        FileType("Markdown",    "text/markdown",         "md"),
        FileType("Markdown",    "text/markdown",         "markdown"),
        FileType("テキスト",     "text/plain",            "txt"),
        FileType("HTML",        "text/html",             "html"),
        FileType("HTML",        "text/html",             "htm"),
        FileType("CSS",         "text/css",              "css"),
        FileType("JavaScript",  "application/javascript","js"),
        FileType("JavaScript",  "application/javascript","mjs"),
        FileType("JSON",        "application/json",      "json"),
        FileType("XML",         "application/xml",       "xml"),
        FileType("YAML",        "text/yaml",             "yml"),
        FileType("YAML",        "text/yaml",             "yaml"),
        FileType("CSV",         "text/csv",              "csv"),
        FileType("TSV",         "text/tab-separated-values", "tsv"),
        FileType("Kotlin",      "text/x-kotlin",         "kt"),
        FileType("Python",      "text/x-python",         "py"),
        FileType("その他",      "*/*",                   ""),
    )

    data class FileType(val label: String, val mime: String, val ext: String)

    fun readText(context: Context, uri: Uri): String {
        return context.contentResolver.openInputStream(uri)?.use {
            it.readBytes().toString(Charsets.UTF_8)
        } ?: ""
    }

    fun writeText(context: Context, uri: Uri, text: String) {
        // "w" だと末尾が古いまま残ることがあるので "wt" (truncate) を使う
        context.contentResolver.openOutputStream(uri, "wt")?.use {
            it.write(text.toByteArray(Charsets.UTF_8))
            it.flush()
        }
    }

    fun displayName(context: Context, uri: Uri): String {
        val doc = DocumentFile.fromSingleUri(context, uri)
        return doc?.name ?: "新規ファイル"
    }

    /** ファイル名から「MD」「TXT」などのラベルを返す */
    fun typeLabel(name: String): String {
        val idx = name.lastIndexOf('.')
        return if (idx >= 0 && idx < name.length - 1)
            name.substring(idx + 1).uppercase()
        else "TXT"
    }
}
