package com.example.noteapp

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 軽量Markdown→Composable変換器。
 * 対応: 見出し #〜######、リスト(-,*,+,1.)、引用>、水平線---、
 *      コードブロック```、インライン `code`、太字**, 斜体*, 打消~~,
 *      リンク[text](url)
 */
object MarkdownRenderer {

    @Composable
    fun Render(source: String, modifier: Modifier = Modifier) {
        val blocks = parseBlocks(source)
        Column(modifier = modifier) {
            blocks.forEach { block ->
                RenderBlock(block)
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    // -------- Block parsing --------

    private sealed class Block {
        data class Heading(val level: Int, val text: String) : Block()
        data class Paragraph(val text: String) : Block()
        data class Quote(val text: String) : Block()
        data class BulletList(val items: List<String>) : Block()
        data class OrderedList(val items: List<String>) : Block()
        data class Code(val lang: String, val code: String) : Block()
        object HR : Block()
        object Blank : Block()
    }

    private fun parseBlocks(src: String): List<Block> {
        val lines = src.split("\n")
        val out = mutableListOf<Block>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]

            // Code fence
            if (line.trimStart().startsWith("```")) {
                val lang = line.trim().removePrefix("```").trim()
                val sb = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                    sb.append(lines[i]).append("\n")
                    i++
                }
                if (i < lines.size) i++ // closing fence
                out += Block.Code(lang, sb.toString().trimEnd('\n'))
                continue
            }

            // Blank line
            if (line.isBlank()) {
                out += Block.Blank
                i++
                continue
            }

            // HR
            val trimmed = line.trim()
            if (trimmed.matches(Regex("^(-{3,}|\\*{3,}|_{3,})$"))) {
                out += Block.HR
                i++
                continue
            }

            // Heading
            val headingMatch = Regex("^(#{1,6})\\s+(.*)$").matchEntire(line)
            if (headingMatch != null) {
                val level = headingMatch.groupValues[1].length
                out += Block.Heading(level, headingMatch.groupValues[2].trim())
                i++
                continue
            }

            // Quote (consume consecutive >)
            if (line.trimStart().startsWith(">")) {
                val sb = StringBuilder()
                while (i < lines.size && lines[i].trimStart().startsWith(">")) {
                    sb.append(lines[i].trimStart().removePrefix(">").trimStart()).append("\n")
                    i++
                }
                out += Block.Quote(sb.toString().trimEnd('\n'))
                continue
            }

            // Bullet list
            if (Regex("^\\s*[-*+]\\s+.*").matches(line)) {
                val items = mutableListOf<String>()
                while (i < lines.size && Regex("^\\s*[-*+]\\s+.*").matches(lines[i])) {
                    items += lines[i].replaceFirst(Regex("^\\s*[-*+]\\s+"), "")
                    i++
                }
                out += Block.BulletList(items)
                continue
            }

            // Ordered list
            if (Regex("^\\s*\\d+\\.\\s+.*").matches(line)) {
                val items = mutableListOf<String>()
                while (i < lines.size && Regex("^\\s*\\d+\\.\\s+.*").matches(lines[i])) {
                    items += lines[i].replaceFirst(Regex("^\\s*\\d+\\.\\s+"), "")
                    i++
                }
                out += Block.OrderedList(items)
                continue
            }

            // Paragraph — gather until blank / block boundary
            val pBuf = StringBuilder(line)
            i++
            while (i < lines.size && lines[i].isNotBlank() &&
                !lines[i].trimStart().startsWith("#") &&
                !lines[i].trimStart().startsWith(">") &&
                !lines[i].trimStart().startsWith("```") &&
                !Regex("^\\s*[-*+]\\s+.*").matches(lines[i]) &&
                !Regex("^\\s*\\d+\\.\\s+.*").matches(lines[i])
            ) {
                pBuf.append("\n").append(lines[i])
                i++
            }
            out += Block.Paragraph(pBuf.toString())
        }
        return out
    }

    // -------- Block rendering --------

    @Composable
    private fun RenderBlock(block: Block) {
        when (block) {
            is Block.Heading -> {
                val (size, weight) = when (block.level) {
                    1 -> 28.sp to FontWeight.Bold
                    2 -> 23.sp to FontWeight.Bold
                    3 -> 19.sp to FontWeight.SemiBold
                    4 -> 17.sp to FontWeight.SemiBold
                    else -> 15.sp to FontWeight.SemiBold
                }
                Column {
                    Text(
                        text = renderInline(block.text),
                        fontSize = size,
                        fontWeight = weight,
                        color = NoteColors.PreviewFg,
                    )
                    if (block.level <= 2) {
                        Spacer(Modifier.height(4.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(if (block.level == 1) 2.dp else 1.dp)
                                .background(
                                    if (block.level == 1) NoteColors.Accent
                                    else Color(0xFFDDDDDD)
                                )
                        )
                    }
                }
            }
            is Block.Paragraph -> {
                Text(
                    text = renderInline(block.text),
                    fontSize = 15.sp,
                    color = NoteColors.PreviewFg,
                    lineHeight = 26.sp,
                )
            }
            is Block.Quote -> {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF0F0F5), RoundedCornerShape(4.dp))
                ) {
                    Box(
                        Modifier
                            .width(4.dp)
                            .fillMaxWidth()
                            .background(NoteColors.Accent)
                    )
                    Box(Modifier.width(4.dp))
                    Text(
                        text = renderInline(block.text),
                        fontSize = 15.sp,
                        color = Color(0xFF555555),
                        fontStyle = FontStyle.Italic,
                        modifier = Modifier.padding(10.dp),
                    )
                }
            }
            is Block.BulletList -> {
                Column {
                    block.items.forEach { item ->
                        Row {
                            Text("•  ", fontSize = 15.sp, color = NoteColors.PreviewFg)
                            Text(
                                text = renderInline(item),
                                fontSize = 15.sp,
                                color = NoteColors.PreviewFg,
                                lineHeight = 24.sp,
                            )
                        }
                    }
                }
            }
            is Block.OrderedList -> {
                Column {
                    block.items.forEachIndexed { idx, item ->
                        Row {
                            Text("${idx + 1}.  ", fontSize = 15.sp, color = NoteColors.PreviewFg)
                            Text(
                                text = renderInline(item),
                                fontSize = 15.sp,
                                color = NoteColors.PreviewFg,
                                lineHeight = 24.sp,
                            )
                        }
                    }
                }
            }
            is Block.Code -> {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(NoteColors.Bg, RoundedCornerShape(8.dp))
                        .padding(14.dp)
                        .horizontalScroll(rememberScrollState())
                ) {
                    Text(
                        text = block.code,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        color = NoteColors.OnBg,
                        lineHeight = 20.sp,
                    )
                }
            }
            Block.HR -> {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFFDDDDDD))
                )
            }
            Block.Blank -> { /* spacer only */ }
        }
    }

    // -------- Inline rendering --------

    /**
     * インライン記法を AnnotatedString に変換。
     * 対応: **bold**, *italic* / _italic_, ~~strike~~, `code`, [text](url)
     */
    private fun renderInline(text: String): AnnotatedString = buildAnnotatedString {
        var i = 0
        while (i < text.length) {
            val rest = text.substring(i)

            // Inline code
            val codeMatch = Regex("^`([^`]+)`").find(rest)
            if (codeMatch != null) {
                withStyle(
                    SpanStyle(
                        fontFamily = FontFamily.Monospace,
                        background = Color(0xFFEEEEEE),
                        color = Color(0xFFC73852),
                        fontSize = 14.sp,
                    )
                ) { append(codeMatch.groupValues[1]) }
                i += codeMatch.value.length
                continue
            }

            // Link [text](url)
            val linkMatch = Regex("^\\[([^]]+)]\\(([^)]+)\\)").find(rest)
            if (linkMatch != null) {
                withStyle(
                    SpanStyle(
                        color = NoteColors.Accent,
                        textDecoration = TextDecoration.Underline,
                    )
                ) { append(linkMatch.groupValues[1]) }
                i += linkMatch.value.length
                continue
            }

            // Bold **xxx**
            val boldMatch = Regex("^\\*\\*([^*]+)\\*\\*").find(rest)
            if (boldMatch != null) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color(0xFF1A1A2E))) {
                    append(boldMatch.groupValues[1])
                }
                i += boldMatch.value.length
                continue
            }

            // Italic *xxx* or _xxx_
            val italicMatch = Regex("^(?:\\*([^*]+)\\*|_([^_]+)_)").find(rest)
            if (italicMatch != null) {
                val inner = italicMatch.groupValues[1].ifEmpty { italicMatch.groupValues[2] }
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(inner) }
                i += italicMatch.value.length
                continue
            }

            // Strikethrough ~~xxx~~
            val strikeMatch = Regex("^~~([^~]+)~~").find(rest)
            if (strikeMatch != null) {
                withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                    append(strikeMatch.groupValues[1])
                }
                i += strikeMatch.value.length
                continue
            }

            append(text[i])
            i++
        }
    }
}
