package com.example.noteapp

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * WebView 経由で Android 標準の印刷ダイアログを出す。
 * ここから「PDFとして保存」「プリンタで印刷」両方が可能。
 */
object PrintHelper {

    fun printMarkdown(context: Context, title: String, markdown: String) {
        val html = buildPrintHtml(title, markdown)
        val webView = WebView(context)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                val printManager =
                    context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = view.createPrintDocumentAdapter(title)
                printManager.print(
                    title,
                    adapter,
                    PrintAttributes.Builder().build(),
                )
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    /**
     * マークダウンをそのまま WebView で描画するためのHTML。
     * ブラウザ側の方が CSS ベースの綺麗な印刷レイアウトを作りやすい。
     * marked.js をCDNから読み込んで描画。
     */
    private fun buildPrintHtml(title: String, markdown: String): String {
        // エスケープして <script> に安全に埋め込む
        val escaped = markdown
            .replace("\\", "\\\\")
            .replace("`", "\\`")
            .replace("$", "\\$")
        val safeTitle = title.replace("<", "&lt;").replace(">", "&gt;")
        return """
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>$safeTitle</title>
<script src="https://cdn.jsdelivr.net/npm/marked@12.0.0/marked.min.js"></script>
<style>
  body { font-family: -apple-system, "Noto Sans JP", sans-serif; color:#000; padding:18mm; line-height:1.7; }
  h1 { font-size:22pt; border-bottom:2px solid #e94560; padding-bottom:.3em; }
  h2 { font-size:17pt; border-bottom:1px solid #ddd; padding-bottom:.2em; }
  h3 { font-size:14pt; }
  p  { margin:.6em 0; }
  code { background:#f0f0f0; color:#c73852; padding:2px 5px; border-radius:3px; font-family:monospace; }
  pre { background:#f5f5f5; padding:10pt; border:1px solid #ddd; border-radius:4pt; overflow:auto;
        page-break-inside:avoid; font-family:monospace; font-size:9pt; }
  pre code { background:none; color:#000; padding:0; }
  blockquote { border-left:4px solid #e94560; background:#f8f8f8; padding:.5em 1em; margin:.8em 0; color:#555; }
  table { border-collapse:collapse; margin:1em 0; width:100%; }
  th,td { border:1px solid #ddd; padding:6pt 10pt; }
  th { background:#f0f0f5; }
  a { color:#000; }
  hr { border:none; border-top:1px solid #ddd; margin:1em 0; }
  @page { margin:18mm; }
</style>
</head>
<body>
<div id="content"></div>
<script>
  const md = `$escaped`;
  if (window.marked) {
    marked.setOptions({ breaks:true, gfm:true });
    document.getElementById('content').innerHTML = marked.parse(md);
  } else {
    document.getElementById('content').textContent = md;
  }
</script>
</body>
</html>
        """.trimIndent()
    }
}
