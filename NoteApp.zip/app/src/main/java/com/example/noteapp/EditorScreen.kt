package com.example.noteapp

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun EditorScreen() {
    val context = LocalContext.current

    var textField by remember { mutableStateOf(TextFieldValue("")) }
    var fileUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("新規ファイル") }
    var typeLabel by remember { mutableStateOf("TXT") }
    var isModified by remember { mutableStateOf(false) }
    var isPreview by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    val lineCount by remember {
        derivedStateOf {
            if (textField.text.isEmpty()) 0 else textField.text.count { it == '\n' } + 1
        }
    }

    // --- SAF launchers ---
    val openLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: SecurityException) { /* ignore */ }

            val content = FileHelper.readText(context, uri)
            val name = FileHelper.displayName(context, uri)
            textField = TextFieldValue(content, selection = TextRange(0))
            fileUri = uri
            fileName = name
            typeLabel = FileHelper.typeLabel(name)
            isModified = false
            toast = "📂 $name を開きました"
        }
    }

    val createLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        if (uri != null) {
            FileHelper.writeText(context, uri, textField.text)
            val name = FileHelper.displayName(context, uri)
            fileUri = uri
            fileName = name
            typeLabel = FileHelper.typeLabel(name)
            isModified = false
            toast = "✅ $name に保存しました"
        }
    }

    fun doSave() {
        val uri = fileUri
        if (uri == null) {
            createLauncher.launch(suggestInitialName(fileName))
        } else {
            FileHelper.writeText(context, uri, textField.text)
            isModified = false
            toast = "✅ 保存しました"
        }
    }

    fun doNew() {
        if (isModified) {
            pendingAction = {
                textField = TextFieldValue("")
                fileUri = null
                fileName = "新規ファイル"
                typeLabel = "TXT"
                isModified = false
            }
        } else {
            textField = TextFieldValue("")
            fileUri = null
            fileName = "新規ファイル"
            typeLabel = "TXT"
        }
    }

    fun doOpen() {
        val openAction: () -> Unit = {
            openLauncher.launch(arrayOf("*/*"))
        }
        if (isModified) pendingAction = openAction else openAction()
    }

    fun doPrint() {
        PrintHelper.printMarkdown(
            context,
            fileName.substringBeforeLast('.', fileName),
            textField.text
        )
    }

    fun insertText(toInsert: String) {
        val tf = textField
        val start = tf.selection.start
        val end = tf.selection.end
        val newText = tf.text.substring(0, start) + toInsert + tf.text.substring(end)
        val cursor = start + toInsert.length
        textField = TextFieldValue(newText, selection = TextRange(cursor))
        isModified = true
    }

    fun insertLinePrefix(prefix: String) {
        val tf = textField
        val start = tf.selection.start
        val lineStart = tf.text.lastIndexOf('\n', (start - 1).coerceAtLeast(0)).let {
            if (it < 0) 0 else it + 1
        }
        val newText = tf.text.substring(0, lineStart) + prefix + tf.text.substring(lineStart)
        val cursor = start + prefix.length
        textField = TextFieldValue(newText, selection = TextRange(cursor))
        isModified = true
    }

    // Toast auto-dismiss
    LaunchedEffect(toast) {
        if (toast != null) {
            delay(2000)
            toast = null
        }
    }

    // Pending discard dialog
    if (pendingAction != null) {
        AlertDialog(
            onDismissRequest = { pendingAction = null },
            containerColor = NoteColors.Surface,
            title = { Text("未保存の変更があります", color = NoteColors.OnBg) },
            text = { Text("破棄しますか？", color = NoteColors.OnBg2) },
            confirmButton = {
                TextButton(onClick = {
                    pendingAction?.invoke()
                    pendingAction = null
                }) { Text("破棄", color = NoteColors.Accent) }
            },
            dismissButton = {
                TextButton(onClick = { pendingAction = null }) {
                    Text("キャンセル", color = NoteColors.OnBg2)
                }
            }
        )
    }

    // ---- Layout ----
    Box(
        Modifier
            .fillMaxSize()
            .background(NoteColors.Bg)
    ) {
        Column(Modifier.fillMaxSize()) {
            Header(fileName = fileName, isModified = isModified)
            // 1段目
            ToolbarRow(background = NoteColors.Surface) {
                ToolbarButton(Icons.Default.Add, "新規", onClick = ::doNew)
                ToolbarButton(Icons.Default.FolderOpen, "開く", onClick = ::doOpen)
                AccentButton(Icons.Default.Save, "保存", onClick = ::doSave)
                Divider()
                ToolbarButton(
                    icon = if (isPreview) Icons.Default.Edit else Icons.Default.Visibility,
                    label = if (isPreview) "編集" else "プレビュー",
                    onClick = { isPreview = !isPreview }
                )
                ToolbarButton(Icons.Default.Print, "印刷", onClick = ::doPrint)
            }
            // 2段目
            ToolbarRow(background = NoteColors.SurfaceEdit) {
                IconOnlyButton(Icons.Default.FormatBold, "太字") {
                    insertText("**太字**")
                }
                IconOnlyButton(Icons.Default.FormatItalic, "斜体") {
                    insertText("*斜体*")
                }
                IconOnlyButton(Icons.Default.Title, "見出し") {
                    insertLinePrefix("# ")
                }
                IconOnlyButton(Icons.Default.FormatListBulleted, "リスト") {
                    insertLinePrefix("- ")
                }
                IconOnlyButton(Icons.Default.FormatQuote, "引用") {
                    insertLinePrefix("> ")
                }
                IconOnlyButton(Icons.Default.Code, "コードブロック") {
                    insertText("```\n\n```")
                }
            }

            // Editor / Preview
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (isPreview) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(NoteColors.PreviewBg)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 24.dp)
                    ) {
                        MarkdownRenderer.Render(textField.text)
                    }
                } else {
                    BasicTextField(
                        value = textField,
                        onValueChange = {
                            textField = it
                            if (!isModified && it.text != "") isModified = true
                            else if (it.text != textField.text) isModified = true
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .background(NoteColors.Bg)
                            .padding(horizontal = 16.dp, vertical = 20.dp)
                            .verticalScroll(rememberScrollState()),
                        textStyle = TextStyle(
                            color = NoteColors.OnBg,
                            fontSize = 15.sp,
                            lineHeight = 24.sp,
                            fontFamily = FontFamily.Monospace,
                        ),
                        cursorBrush = SolidColor(NoteColors.Accent),
                        decorationBox = { inner ->
                            if (textField.text.isEmpty()) {
                                Text(
                                    "ここに入力…",
                                    color = NoteColors.OnBg2.copy(alpha = 0.5f),
                                    fontSize = 15.sp,
                                    fontFamily = FontFamily.Monospace,
                                )
                            }
                            inner()
                        }
                    )
                }
            }

            // Status bar
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(NoteColors.Surface)
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("📄 $lineCount 行", color = NoteColors.OnBg2, fontSize = 11.sp)
                Text("✏️ ${textField.text.length} 文字", color = NoteColors.OnBg2, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(typeLabel, color = NoteColors.OnBg2, fontSize = 11.sp)
            }
        }

        // Toast
        toast?.let { msg ->
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 60.dp)
                    .background(Color(0xFF222240), RoundedCornerShape(100.dp))
                    .border(1.dp, NoteColors.Border, RoundedCornerShape(100.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(msg, color = NoteColors.OnBg, fontSize = 13.sp)
            }
        }
    }
}

// --- UI pieces ---

@Composable
private fun Header(fileName: String, isModified: Boolean) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(NoteColors.Surface)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "note",
                color = NoteColors.OnBg,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                ".",
                color = NoteColors.Accent,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = fileName,
            color = NoteColors.OnBg2,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (isModified) {
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(NoteColors.Accent)
            )
        } else {
            Spacer(Modifier.width(7.dp))
        }
    }
}

@Composable
private fun ToolbarRow(
    background: Color,
    content: @Composable () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(background)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        content()
    }
}

@Composable
private fun ToolbarButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(NoteColors.Border)
            .clickableCompat(onClick)
            .padding(horizontal = 11.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Icon(icon, contentDescription = label, tint = NoteColors.OnBg2, modifier = Modifier.size(16.dp))
        Text(label, color = NoteColors.OnBg2, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun AccentButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(NoteColors.Accent)
            .clickableCompat(onClick)
            .padding(horizontal = 13.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(16.dp))
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun IconOnlyButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(7.dp))
            .clickableCompat(onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = label, tint = NoteColors.OnBg2, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun Divider() {
    Box(
        Modifier
            .width(1.dp)
            .height(24.dp)
            .background(NoteColors.Border)
    )
}

// シンプルなクリック付与（デフォルトリップル使用）
@Composable
private fun Modifier.clickableCompat(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(onClick = onClick))

/**
 * CreateDocument に渡す初期ファイル名を決める。
 * 既存ファイル名があれば流用、なければ "note.md" を提案。
 */
private fun suggestInitialName(current: String): String {
    return if (current == "新規ファイル" || current.isBlank()) "note.md" else current
}
