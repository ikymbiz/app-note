# NoteApp (Kotlin / Jetpack Compose)

HTML版エディタのKotlin/Android Compose 移植版です。

## 機能

- 📝 テキスト/Markdownエディタ
- 👁 プレビュー（Markdownレンダリング）
- 🖨 印刷 / PDF出力（Android 標準印刷フレームワーク経由 → 「PDFとして保存」可）
- 💾 SAF (Storage Access Framework) によるファイル読み書き
- 📂 任意の拡張子で保存可能（.md / .txt / .html / .css / .js / .json / .kt …）
- ツールバー2段構成（ファイル操作 / 編集操作）

## ビルド方法

1. **Android Studio** (Hedgehog 以降推奨) で `NoteApp` フォルダを開く
2. Gradle sync 完了を待つ
3. 実機またはエミュレータ (API 26 以上) で実行

### コマンドラインでのビルド

```bash
cd NoteApp
./gradlew assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk が生成される
```

Gradle Wrapper (`gradlew`, `gradle/wrapper/*`) はAndroid Studioが自動生成するため、
このZIPには `gradle-wrapper.properties` のみ含まれています。Android Studio で最初に開いた際に
自動で `gradlew` と `gradle-wrapper.jar` が生成されます。

## CI / CD (GitHub Actions)

リポジトリを GitHub に push するだけで以下が自動実行されます。

### ビルドワークフロー (`.github/workflows/build.yml`)
- push / PR ごとに **debug APK** をビルド
- Lint レポートを生成
- 成果物を **Artifacts** からダウンロード可能（14日保持）

### リリースワークフロー (`.github/workflows/release.yml`)
- `git tag v1.0.0 && git push --tags` のようにタグを push すると起動
- **release APK** をビルドして **GitHub Release** に自動添付

### 署名付きリリースAPKを出したい場合

以下の 4 つの Secrets をリポジトリに設定してください：

| Secret 名 | 説明 |
|---|---|
| `KEYSTORE_BASE64` | `base64 -w 0 release.keystore` の出力 |
| `KEYSTORE_PASSWORD` | キーストアのパスワード |
| `KEY_ALIAS` | キーのエイリアス |
| `KEY_PASSWORD` | キーのパスワード |

Secrets が設定されていない場合は **unsigned APK** が生成されます
（ローカルで `apksigner` を使って手動署名できます）。

## プロジェクト構成

```
NoteApp/
├── build.gradle.kts             (root)
├── settings.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/noteapp/
        │   ├── MainActivity.kt           // エントリポイント
        │   ├── EditorScreen.kt           // メインUI
        │   ├── MarkdownRenderer.kt       // 軽量Markdownパーサ
        │   ├── FileHelper.kt             // SAFファイルI/O
        │   ├── PrintHelper.kt            // 印刷/PDF
        │   └── Theme.kt                  // カラーテーマ
        └── res/
            ├── values/
            │   ├── colors.xml
            │   └── themes.xml
            ├── drawable/
            │   ├── ic_launcher_background.xml
            │   └── ic_launcher_foreground.xml
            └── mipmap-anydpi-v26/
                ├── ic_launcher.xml
                └── ic_launcher_round.xml
```

## ライセンス

個人利用・学習目的のサンプル。
